# Raw assets folder
